#!/usr/bin/env python
# -*- coding: utf-8 -*-


# AGOPIAN Paul
# RODRIGUEZ Clément

#################################################  BIENVENUE   #######################################


################ IMPORTATION DES MODULES ##################


EMULATE_HX711=False

referenceUnit = 1

if not EMULATE_HX711:
    import RPi.GPIO as GPIO
    from hx711 import HX711
else:
    from emulated_hx711 import HX711


#from Tkinter import*                # python2
from tkinter import*                # python3
import time
from enum import Enum
import sys
import mysql.connector
from mysql.connector import Error
import datetime
from tkinter import messagebox     # python3
#import tkMessageBox as messagebox                 # python2



######################  CLASSE GESTION DES CLICS SUR LES TABLES ##################



class ChangeColorTables:


    def __init__(self, master,**kwargs):#, grid=np.diag(np.ones(3))):

        ### GEOMETRIE DE LA FENETRE

        self.master=master
        pad=3
        self._geom='200x200+0+0'
        master.geometry("%dx%d+0+0" %(
            master.winfo_screenwidth()-pad, master.winfo_screenheight()-pad))
        master.bind('<Escape>',self.toggle_geom)

        ### ATTRIBUTS
        self.buttonsList = [Button()]*6
        self.tablesColorList = ["white","white","white","white","white","white"]
        self.clignoteTabBool = [False, False, False, False, False, False]
        self.curIndex=0

        self.displayTables()

        self.displayLegend()

    def displayTables(self):
                ### AFFICHAGE DES TABLES
        nbTable=0
        shiftY=0

        for i in range(2):
            shiftY=shiftY+1
            shiftX=0
            for j in range(3):
                shiftX=shiftX+1
                self.buttonsList[nbTable]=Button(lfTables, text='Table'+(str)(nbTable+1), width=10, height=5, bg=self.tablesColorList[nbTable], activebackground=self.tablesColorList[nbTable])#, command= lambda : changeTableColor(nbTable))
                self.buttonsList[nbTable].grid(column=shiftX, row=shiftY, padx=shiftX*50, pady=shiftY*50)

                self.buttonsList[nbTable].bind("<Button-1>", lambda event, index=nbTable : self.callback(self.buttonsList[index],index))
                nbTable=nbTable+1

                self.clignote()

    # Cette fonction permet de redimensionner la fenetre.
    def toggle_geom(self,event):
        geom=self.master.winfo_geometry()
        print(geom,self._geom)
        self.master.geometry(self._geom)
        self._geom=geom


    choixPlat=''

    # Fait le changement de couleur de la table sur laquelle on a cliquée
    # ajoute le dernier poids mesuré dans la base de données
    def callback(self, button, index):

    ####gestion des couleurs
        global nbMesuresIdentiques
        global fenetre
        global poidsFinal
        global choixPlat

        if self.clignoteTabBool[index]==False:

            color=self.tablesColorList[index]

            if color=="white":
                color="green"
            elif color=="green":
                color="orange"
            elif color=="orange":
                color="red"
            elif color=="red":
                color="black"
            elif color=="black":
                color="white"

            # changement de la couleur de police si la table est noire ou verte...
            if color == "black" or color == "green" or color == "red":
                button['fg'] = "white"
            else:
                button['fg'] = "black"

            self.tablesColorList[index]=color
            button['bg'] = color
            button['activebackground']=color

            print(self.tablesColorList[index])

        #### menuchooser
            if button['bg']=="green":
                typePlat="Entree"
                carte=entreesCarte
                choixPlat = MenuChooser(fenetre,typePlat,"Selectionner un plat",carte)
            elif button['bg']=="orange":
                typePlat="Plat"
                carte=platsCarte
                if choixPlat.result is not None:
                    insererPoidsBdd(choixPlat.result,poidsFinal)
                choixPlat = MenuChooser(fenetre,typePlat,"Selectionner un plat",carte)
            elif button['bg']=="red":
                typePlat="Dessert"
                carte= dessertsCarte
                if choixPlat.result is not None:
                    insererPoidsBdd(choixPlat.result,poidsFinal)
                choixPlat = MenuChooser(fenetre,typePlat,"Selectionner un plat",carte)


        else:
            button['bg']=self.tablesColorList[index]
            self.clignoteTabBool[index]=False
            nbMesuresIdentiques=0
            #print("------  ",index)



    ### fonction clignotage des tables
    def clignote(self):

        if self.clignoteTabBool[self.curIndex]:
            cur_color=self.buttonsList[self.curIndex]['bg']
            if cur_color=="white":
                next_color="black"
            else:
                next_color="white"
            self.buttonsList[self.curIndex].config(bg=next_color)

        if self.curIndex==5:
            self.curIndex=0
        else:
            self.curIndex=self.curIndex+1

        self.master.after(100,self.clignote)


    def test(self):
        global cnt
        cnt=cnt+1
        print(cnt)
        self.master.after(200,self.test())



    def displayLegend(self):
        # Création du canvas contenant la legende
        canvas = Canvas(lfTables, width=980, height=100, bg="white")
        canvas.pack(pady=400,side=BOTTOM)

        canvas.create_rectangle(50,50,100,70,fill="white")
        canvas.create_text((75,60), text="Libre")

        canvas.create_rectangle(150,50,200,70,fill="green")
        canvas.create_text((175,60), text="Entrée", fill="white")

        canvas.create_rectangle(250,50,300,70,fill="orange")
        canvas.create_text((275,60), text="Plat")

        canvas.create_rectangle(350,50,400,70,fill="red")
        canvas.create_text((375,60), text="Dessert", fill="white")

        canvas.create_rectangle(450,50,500,70,fill="black")
        canvas.create_text((475,60), text="Café", fill="white")




#########################  MENU CHOOSER : s'active au clic d'une table  #################


class MenuChooser(Toplevel):
#code recupere sur stackoverflow

    def __init__(self,parent,title,question,carte):
        Toplevel.__init__(self,parent)
        self.title(title)
        self.question = question
        self.transient(parent)
        self.protocol("WM_DELETE_WINDOW",self.cancel)
        self.carte = carte
        self.result = '_'
        self.createWidgets()
        self.wait_visibility()
        self.grab_set()
        self.wait_window()

    def createWidgets(self):
        frmQuestion = Frame(self)
        Label(frmQuestion,text=self.question).grid()
        frmQuestion.grid(row=1)
        frmButtons = Frame(self)
        frmButtons.grid(row=2)
        column = 0
        for plat in self.carte:
            btn = Button(frmButtons,text=plat,command=lambda x=plat:self.setOption(x))
            btn.grid(column=column,row=0)
            column += 1

    def setOption(self,optionSelected):
        self.result = optionSelected
        self.destroy()

    def cancel(self):
        self.result = None
        self.destroy()




####################   FONCTIONS ANNEXES  #######################

# Pour réaliser la partie concernant la mesure de poids avec la balance hx711 nous avons utilisé une partie du projet suivant: https://github.com/tatobari/hx711py

def mesure():
    try:
        global poidsPrecPlat
        global nbMesuresIdentiques
        global curColor
        global poidsFinal

        # on utilise
        val = max(0,hx.get_weight(5))

        poidsAssiette=600.0
        poidsPlat=val-poidsAssiette
        print("Le plat pèse %.2f"%poidsPlat,"g")

        # detection mesures identiques
        if poidsPrecPlat-1<=poidsPlat and poidsPlat<=poidsPrecPlat+1:
            nbMesuresIdentiques+=1
        else:
            nbMesuresIdentiques=0

        # si trop longtemps identique ET assiette toujours là, cignoter !
        if nbMesuresIdentiques>=6 and poidsPlat>0:
            print("/!\ TABLE A DEBARASSER /!\ \n")
            app.clignoteTabBool[0]=True


        #print("****** Poids prec = ",poidsPrecPlat)
        #print("------ Poids current = ",poidsPlat)


        ### gestion fin du plat
        #poids <0 si on enleve l'assiette
        if poidsPlat<-10 and poidsPrecPlat>0:
            # donc le dernier poids du plat est la derniere mesure >0 (avant que le serveur dne debarasse l'assiette)
            poidsFinal = poidsPrecPlat
            print(poidsFinal)

        poidsPrecPlat=poidsPlat

        hx.power_down()
        hx.power_up()


    except (KeyboardInterrupt, SystemExit):
        cleanAndExit()

    # on realise une mesure toutes les 2s
    fenetre.after(2000,mesure)



#########################  DONNE LA MOYENNE DES POIDS POUR UN PLAT A PARTIR DE LA BDD ##################""

def getMoyPlat(nom_plat):

        global fenetre

        try:
            mySQLConnection = mysql.connector.connect(host='localhost',database='PoidsPlats',user='root',password='eglisepi17')
            cursor = mySQLConnection.cursor(buffered=True)
            sql_select_query = """select * from PoidsPlats where nom_plat = %s"""
            cursor.execute(sql_select_query, (nom_plat,))
            record = cursor.fetchall()

            moy=0
            cnt=0
            for row in record:
                #print("Id = ", row[0])
                #print("Poids = ", row[1])
                #print("Nom plat = ", row[2])
                moy+=row[1]
                cnt+=1

            moy=moy/cnt
            print("Le ",datetime.date.today())
            moyStr="Le poids moyen des restes pour le plat %s est de %.1f g." %(nom_plat,moy)
            messagebox.showinfo('Resultat',moyStr)
            print(moyStr)
            return moyStr

        except mysql.connector.Error as error:
            print("Failed to get record from MySQL table: {}".format(error))

        except ZeroDivisionError as e:
            erStr="Pas de données de poids enregistrées pour ce plat"
            messagebox.showinfo('Resultat',erStr)
            print(erStr)

        finally:
            if (mySQLConnection.is_connected()):
                cursor.close()
                mySQLConnection.close()
                #print("MySQL connection is closed")


######################### INSERE UN POIDS DANS LA BDD POUR UN PLAT PRECIS  ########################

def insererPoidsBdd(nom_plat, poids):

     try:
         mySQLConnection = mysql.connector.connect(host='localhost',database='PoidsPlats',user='root',password='eglisepi17')
         cursor = mySQLConnection.cursor(buffered=True)
         sql_insert_query = """INSERT INTO PoidsPlats (poids,nom_plat) VALUES (%s,%s)"""
         val = (poids,nom_plat)
         cursor.execute(sql_insert_query, val)
         mySQLConnection.commit()

     except mysql.connector.Error as error:
         print("Failed to get record from MySQL table: {}".format(error))

     finally:
         if (mySQLConnection.is_connected()):
              cursor.close()
              mySQLConnection.close()
              #print("MySQL connection is closed")


# Fonction pour l'initialisation de la balance
def cleanAndExit():
    print("Cleaning...")

    if not EMULATE_HX711:
        GPIO.cleanup()

    print("Bye!")
    sys.exit()



########################################################################################

####################################   MAIN    ##########################################

#########################################################################################


###################  FRAMES  ######################
#Les Frames contiendront les boutons, canvas, textes et dessins.
# Pour chaque frame, on créé un objet à l'aide de la classe LabelFrame(). On spécifie le titre, les dimensions.
# Bien entendu, elles sont toutes contenues dans l'objet fenetre.
# On les place avec grid() en indiquant la colonne avec column et la ligne avec row. Ou avec pack() en indiquant le coté dans side.
# grid_propagate(False) permet d'étaler la frame même si on y positionne un widget comme un bouton.



#la fenetre principale
fenetre=Tk()

fenetre.title("Suivi des repas")
fenetre['bg']='white'

lfAttente = LabelFrame(fenetre, text="Temps d'attente depuis dernier plat", height=300,width=1420)
lfAttente.grid(row=0,sticky='nw',column=1,columnspan=2)
lfAttente.grid_propagate(False)

lfMenu = LabelFrame(fenetre, text="Menu",height=1300,width=500)
lfMenu.grid(column=0,row=0,rowspan=2)
lfMenu.grid_propagate(False)

canvasMenu = Canvas(lfMenu, width=500, height=1300, bg="white")
canvasMenu.pack()
canvasMenu.create_text((250,300), font=('Helvetica',15),text="********* Carte **********\n\n\n * Entrée: \n    - Salade chèvre chaud au miel\n    - Salade nicoise\n     - Coquilles Saint-Jacques\n     - Soupe à l'oignon\n\n * Plat:\n    - Pizza aux 4 fromages\n    - Lasagnes\n    - Steak Tartare\n    - Burger Frites\n * Desserts:\n    - Banana Split\n    - Tarte à la fraise\n    - Fondant aux chocolat\n    - Dame Blanche\n\n\n*********************************" )


canvasMenu.create_text((250,700), font=('Helvetica',15),text="--- Commande table n°3 ---\n\n  - 2 plats x\n  - 2 plats y\n  -1 plat z")
canvasMenu.create_text((150,900), text="< Table precedente")
canvasMenu.create_text((350,900), text="Table suivante >")


lfTables = LabelFrame(fenetre, text="Tables",height=700,width=980, bg='white')
lfTables.grid(row=1,column=1, sticky='n')
lfTables.grid_propagate(False)

lfService = LabelFrame(fenetre, text="Statistiques",height=1000,width=500)
lfService.grid(row=1,column=2)
lfService.grid_propagate(False)

#####  AJOUT d'un BOUTON STATISTIQUES###

buttonsGetMoyPlat=Button(lfService, text="Obtenir le poids moyen des restes", width=30, height=5)
buttonsGetMoyPlat.grid(column=0, row=0, padx=50, pady=50)
buttonsGetMoyPlat.bind("<Button-1>", lambda event : getMoyPlat(MenuChooser(fenetre,"Selectionner un plat","Obtenir le poids moyen des restes",carte).result))


###################################  MENU   ########

menubar = Menu(fenetre)

menu1 = Menu(menubar, tearoff=0)
menu1.add_command(label="Charger une nouvelle carte")
menu1.add_command(label="Modifier la configuration des tables")
menu1.add_command(label="Modifier le nombre d'assiettes par table")
menu1.add_separator()
menu1.add_command(label="Quitter")
menubar.add_cascade(label="Fichier", menu=menu1)

menu2 = Menu(menubar, tearoff=0)

menu2.add_command(label="Plug-in 1")
menu2.add_command(label="Plug-in 2")
menu2.add_command(label="Plug-in 3")

menubar.add_cascade(label="Statistiques avancées", menu=menu2)

menu3 = Menu(menubar, tearoff=0)
menu3.add_command(label="A propos")
menubar.add_cascade(label="Aide", menu=menu3)

fenetre.config(menu=menubar)

#######################################

# INSTANCIATION D'UN OBJET ChangeColorTables
app=ChangeColorTables(fenetre)


########################  INITIALISATION DE LA BALANCE  ##############

hx = HX711(5, 6)

hx.set_reading_format("MSB", "MSB")

# etallonage fait avec une assiette de 600g, on avait 224250 environ affiché à l'écran avant l'etalonnage
hx.set_reference_unit(374)

hx.reset()

hx.tare()

print("Tare done! Add weight now...")



#########################################################################

#######################  MESURE  ######################""


poidsPrecPlat=0
poidsFinal=0
nbMesuresIdentiques=0
curColor=app.buttonsList[0]['bg']

# tableaux pour les choix des plats lors des clics sur les tables
entreesCarte = ['salade_chevre','salade_nicoise','soupe_oignon','saint_jacques']
platsCarte = ['pizza_4fromages','steak_tartare','burger_frites','lasagnes']
dessertsCarte = ['banana_split','fondant_choco','dame_blanche','tarte_fraise']

# tableau contenant tous les plats pour le bouton recuperant les stats sur les poids moyens
carte = ['salade_chevre','salade_nicoise','soupe_oignon','saint_jacques','pizza_4fromages','steak_tartare','burger_frites','lasagnes','banana_split','fondant_choco','dame_blanche','tarte_fraise']


fenetre.after(5,mesure)
fenetre.mainloop()


# END

